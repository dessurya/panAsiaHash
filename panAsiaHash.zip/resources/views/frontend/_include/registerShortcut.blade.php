<div id="participant" style="background-image: url('{{ asset('assets/images-base/somesomethingss.jpg') }}');">
	<div class="set-wrapper">
		<div id="set-width" class="width-medium">
			<div id="row">
				<div id="midle">
					<h2>Limited Participant</h2>
					<br>
					<div class="text-center">
						<a class="buton-style" href="{{ route('frontend.registerPayment') }}">REGISTER NOW</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>