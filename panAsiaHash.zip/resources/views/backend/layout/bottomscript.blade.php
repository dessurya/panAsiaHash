<script src="{{ asset('backend/vendors/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ asset('backend/vendors/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('backend/vendors/fastclick/lib/fastclick.js') }}"></script>
<script src="{{ asset('backend/vendors/nprogress/nprogress.js') }}"></script>
<script src="{{ asset('backend/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js') }}"></script>
<script src="{{ asset('backend/vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<!-- Custom Theme Scripts -->
<script src="{{ asset('backend/js/custom.min.js') }}"></script>
