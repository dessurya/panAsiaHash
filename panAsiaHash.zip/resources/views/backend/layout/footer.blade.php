<div class="pull-right">
  <a href="#">PAN ASIA HASH</a>
</div>
<div class="clearfix"></div>
