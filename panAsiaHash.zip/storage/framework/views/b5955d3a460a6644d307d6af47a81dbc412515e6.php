<?php $__env->startSection('title'); ?>
	<title>PAN ASIA HASH | Gallery</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/gallery.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/sub-public.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

	<div id="gallery" class="first-content" style="background-image: url('<?php echo e(asset('assets/images-base/petern.png')); ?>');">
		<img id="das" src="<?php echo e(asset('assets/images-base/das.png')); ?>">
		<div class="set-wrapper">
			<div id="set-width" class="width-medium">
				<h2 id="title">Gallery</h2>
				
				<div id="list-gallery">
					<?php echo $__env->make('frontend.gallery.img-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<div id="appendAjax"></div>
					<div class="clearfix"></div>
					<div class="centered">
						<label id="loadMoreData" class="buton-style" style="cursor: pointer;">SHOW MORE</label>
						<div class="ajax-load text-center" style="display:none;">
							<p>
								<img src="http://demo.itsolutionstuff.com/plugin/loader.gif">Loading More...
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php echo $__env->make('frontend._include.registerShortcut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		var page = 1;
		$("label#loadMoreData").click(function(){
		    page++;
		        loadMoreData(page);
		    	window.setTimeout(function() {
					    makeBox();
				    }, 250);
		});

		function loadMoreData(page){
		  $.ajax(
		        {
		            url: '?page=' + page,
		            type: "get",
		            beforeSend: function()
		            {
		                $('.ajax-load').show();
		            }
		        })
		        .done(function(data)
		        {
		            if(!data.html){
		                $('.ajax-load').hide();
			            $('label#loadMoreData').hide();
		                return;
		            }
		            $('.ajax-load').hide();
		            $("#appendAjax").append(data.html);
		      //       window.setTimeout(function() {
					   //  $('.recipe-show.animation-element').addClass('in-view');
				    // }, 50);
		        })
		        .fail(function(jqXHR, ajaxOptions, thrownError)
		        {
		              alert('server not responding...');
		        });

		}
	</script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
	<script type="text/javascript">
		baguetteBox.run('#list-gallery');

		function makeBox() {
			baguetteBox.run('#list-gallery');
		}
	</script>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend._layout.basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>