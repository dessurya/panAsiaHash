<div id="navbar">
	<div class="set-wrapper">
		<div id="set-width" class="width-large">
			<div id="logo" class="bar">
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.home')); ?>">
							<img src="<?php echo e(asset('assets/images-base/logo-pah.png')); ?>">	
						</a>
						<div id="burger-icon">
							<div></div>
							<div></div>
							<div></div>
						</div>
					</div>
				</div>
			</div>
			<div id="list" class="bar">
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.coming')); ?>" class="<?php echo e(Route::is('frontend.coming') ? 'active' : ''); ?>">
							Who's Coming
						</a>
					</div>
				</div>
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.schedule')); ?>" class="<?php echo e(Route::is('frontend.schedule') ? 'active' : ''); ?>">
							Schedule
						</a>
					</div>
				</div>
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.commitee')); ?>" class="<?php echo e(Route::is('frontend.commitee') ? 'active' : ''); ?>">
							Commitee
						</a>
					</div>
				</div>
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.gallery')); ?>" class="<?php echo e(Route::is('frontend.gallery') ? 'active' : ''); ?>">
							Gallery
						</a>
					</div>
				</div>
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.registerPayment')); ?>" class="<?php echo e(Route::is('frontend.registerPayment') ? 'active' : ''); ?>">
							Registration & Payment
						</a>
					</div>
				</div>
				<div class="midle">
					<div id="col">
						<a href="<?php echo e(route('frontend.goverment-message')); ?>" class="<?php echo e(Route::is('frontend.goverment-message') ? 'active' : ''); ?>">
							Goverment Message
						</a>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>