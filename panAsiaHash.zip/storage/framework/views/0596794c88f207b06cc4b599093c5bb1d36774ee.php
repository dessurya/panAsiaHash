<link href="<?php echo e(asset('backend/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css')); ?>" rel="stylesheet"/>
<?php echo $__env->yieldContent('headscript'); ?>
<link href="<?php echo e(asset('backend/css/custom.min.css')); ?>" rel="stylesheet">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
