<div id="participant" style="background-image: url('<?php echo e(asset('assets/images-base/somesomethingss.jpg')); ?>');">
	<div class="set-wrapper">
		<div id="set-width" class="width-medium">
			<div id="row">
				<div id="midle">
					<h2>Limited Participant</h2>
					<br>
					<div class="text-center">
						<a class="buton-style" href="<?php echo e(route('frontend.registerPayment')); ?>">REGISTER NOW</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>