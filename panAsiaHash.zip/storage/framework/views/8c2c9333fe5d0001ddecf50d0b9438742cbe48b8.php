<?php $__env->startSection('title'); ?>
	<title>PAN ASIA HASH | Goverment Message</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/sub-public.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

	<div class="first-content" style="background-image: url('<?php echo e(asset('assets/images-base/petern.png')); ?>');">
		<img id="das" src="<?php echo e(asset('assets/images-base/das.png')); ?>">
		<div class="set-wrapper">
			<div id="set-width" class="width-medium">
				<h2 id="title">Goverment Message</h2>
				
				<div class="text-center">
					<img src="<?php echo e(asset('assets/images-base/government-massage.png')); ?>" style="margin: 40px auto; width: 80%;">
				</div>
			</div>
		</div>
	</div>

	<?php echo $__env->make('frontend._include.registerShortcut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend._layout.basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>