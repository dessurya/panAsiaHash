<?php $__currentLoopData = $Gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="thumbnail">
	<a class="lightbox" href="<?php echo e(asset('assets/images/'.$list->picture)); ?>">
		<div id="display-img" style="background-image: url('<?php echo e(asset('assets/images/'.$list->picture)); ?>');"></div>
	</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>