<?php $__env->startSection('title'); ?>
  <title>PAN ASIA HASH | Gallery</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headscript'); ?>
<link href="<?php echo e(asset('backend/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
<style type="text/css">
  .thumnail{
    float: left;
    width: 16%;
    padding: 1%;
    margin: 1%;
    border: solid .5px;
    border-radius: 5px;
    text-align: center;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if(Session::has('berhasil')): ?>
  <script>
    window.setTimeout(function() {
      $(".alert-success").fadeTo(700, 0).slideUp(700, function(){
          $(this).remove();
      });
    }, 5000);
  </script>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="alert alert-success alert-dismissible fade in" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <strong><?php echo e(Session::get('berhasil')); ?></strong>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <div class="modal fade modal-form-add" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo e(route('backend.gallery.store')); ?>" method="POST" class="form-horizontal form-label-left" enctype="multipart/form-data">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title" id="myModalLabel2">Add Gallery</h4>
          </div>
          <div class="modal-body">
            <?php echo e(csrf_field()); ?>

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12">Gambar Max 700x700</label>
              <div class="col-md-9 col-sm-9 col-xs-12">
                <input class="form-control col-md-7 col-xs-12" name="picture" type="file" accept=".jpg,.png">
                <?php if($errors->has('picture')): ?>
                  <code><span style="color:red; font-size:12px;"><?php echo e($errors->first('picture')); ?></span></code>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button id="send" type="submit" class="btn btn-success">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Gallery </h2>
          <ul class="nav panel_toolbox">
            <a class="btn btn-success btn-sm" data-toggle='modal' data-target='.modal-form-add'><i class="fa fa-plus"></i> Add</a>
          </ul>
          <div class="clearfix"></div>
        </div>
        <div class="x_content table-responsive">
          <div id="list-gallery">
              <?php $__currentLoopData = $Gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="thumnail">
                <a href="<?php echo e(asset('assets/images/'.$key->picture)); ?>">
                  <img src="<?php echo e(asset('assets/images/'.$key->picture)); ?>" style="height: 90px;">
                </a>
                <hr>
                <a href="<?php echo e(route('backend.gallery.FP', ['id'=> $key->id])); ?>">
                  <span class="label <?php echo e($key->flug_publish == 'N' ? 'label-danger' : 'label-success'); ?>" data-toggle="tooltip" data-placement="top" title="Click to <?php echo e($key->flug_publish == 'N' ? 'Publish' : 'Unpublish'); ?>">
                    <i class="fa <?php echo e($key->flug_publish == 'N' ? 'fa-thumbs-o-down' : 'fa-thumbs-o-up'); ?> "></i> <?php echo e($key->flug_publish == 'N' ? 'Unpublish' : 'Publish'); ?>

                  </span>
                </a>
                &nbsp;
                <a href="<?php echo e(route('backend.gallery.delete', ['id'=> $key->id])); ?>">
                  <span class="label label-danger" data-toggle="tooltip" data-placement="top" title="Click to Delete This Data">
                    <i class="fa fa-trash "></i> Delete
                  </span>
                </a>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script type="text/javascript">
baguetteBox.run('#list-gallery');
</script>
<?php if(Session::has('info-form-add')): ?>
<script>
$('.modal-form-add').modal('show');
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>